<h3>Leave A Comment</h3>
<?php
    if (isset($_POST['user_id'])) {
        $data = array(
                        'user_id' => $_POST['user_id'],
                        'post_id' => $_POST['post_id'],
                        'content' => $_POST['content']
                    );
        post_comment($data);
    }
    $user_info = get_user_info(get_current_username());
    $post_id = $_GET['post_id'];
?>
<form action="" method="post">
    <ul style="list-style: none;">
        <li>
            <input type="hidden" name="user_id" value="<?php echo $user_info['personID']; ?>" />
            <input type="hidden" name="post_id" value="<?php echo $post_id; ?>" />
            <textarea name="content"></textarea>
        </li>
        <li>
            <input type="submit" value="Comment" />
        </li>
    </ul>
</form>