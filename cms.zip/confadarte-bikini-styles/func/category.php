<?php
    include('functions.php');
    get_header();
    $id = $_GET['slug'];
    if (is_category($id) === true) {
        $id = get_category_id_from_slug($id);
        $cat_info = get_category_info($id);
?>
        <h1>Category: <?php echo $cat_info['name']; ?></h1>
<?php
        $posts = get_posts(NULL, $id);
        if (is_array($posts)) {
            foreach ($posts as $post) {
                $name = $post['title'];
                $timestamp = $post['timestamp'];
                $image = $post['image'];
                $link = HTML_ROOT . 'post/' . $post['slug'] . '/';
?>
                <h2><a href="<?php echo $link; ?>"><?php echo $name; ?></a></h2>
                <?php echo date('j/n/Y', strtotime($timestamp)); ?><br />
                <img src="<?php echo $image; ?>" alt="<?php echo $name; ?>" />
<?php
            }
        }
    } else {
        $_GET['error_code'] = '404';
        require ROOT . 'func/thats_an_error.php';
    }
    get_footer();
?>