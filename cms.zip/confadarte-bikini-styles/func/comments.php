<h3>Comments</h3>
<?php
    $post_id = $_GET['post_id'];
    $comments = get_comments(NULL, $post_id, NULL, FALSE);
    if (is_array($comments)) {
        foreach ($comments as $comment) {
            $user_info = get_user_info(get_user_name_from_id($comment['user_id']));
?>
            <h4>By: <?php echo $user_info['first_name'] . ' ' . $user_info['last_name']; ?></h4>
            <?php get_gravatar($user_info['email'], true); ?>
            <p><?php if ($comment['aproved'] == 1) echo $comment['content']; else echo '<strong><em>This comment is wating to be aproved</em></strong>'; ?></p>
<?php
        }
    } else {
?>
<h4>No Comments On This Post</h4>
<?php
    }
?>