<?php if(isset($_SESSION['user'])): ?>
<h3>Welcome <?php echo $_SESSION['firstname'] . ' ' . $_SESSION['lastname']; ?>!</h3>
<a href="<?php echo HTML_ROOT; ?>logout/">Logout</a>
<?php else: ?>
<form action="<?php echo HTML_ROOT; ?>login/" method="post">
<h3>Login</h3>
<ul style="list-style: none;">
<li>
<label for="username">Name:</label><br />
<input type="text" id="username" name="username" />
</li>
<li>
<label for="password">Password:</label><br />
<input type="password" id="password" name="password" />
</li>
<li>
<button type="submit">
Login
</button>
</li>
<li>
<a href="<?php echo HTML_ROOT; ?>register.php">Register</a>
</li>
</ul>
</form>
<?php endif; ?>