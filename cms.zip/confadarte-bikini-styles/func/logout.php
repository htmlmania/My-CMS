<?php logout(); ?>
<a href="javascript:history.back(1)"><< Back</a>