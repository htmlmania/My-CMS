<?php
    loged_in_redirect();
    if (isset($_POST['username'])) {
        $errors = array();
        $requierd_fields = array('username', 'password', 'password_again', 'first_name', 'email', 'birthday');
        foreach($_POST as $key=>$value) {
            if (empty($value) && in_array($key, $requierd_fields) === true) {
                $errors[] = "Fields marked with an asterisk are requeired.";
                break 1;
            }
        }
        if (empty($errors) === true) {
            if(user_exits($_POST['username'])) {
                $errors[] = "The username " . $_POST['username'] . " alredy exits.";
            }
            if (preg_match("/\\s/", $_POST['username']) == true) {
                $errors[] = "Usernames can not contain any spaces.";
            }
            if (strlen($_POST['password']) < 6) {
                $errors[] = "Passowrd can not be under 6 charecters.";
            }
            if ($_POST['password'] <> $_POST['password_again']) {
                $errors[] = "Passwords do not match.";
            }
            if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) == false) {
                $errors[] = "The email " . $_POST['email'] . " is not a valid email.";
            }
            if (email_exits($_POST['email']) === true) {
                $errors[] = "The email " . $_POST['email'] . " is alredy in use.";
            }
            if (empty($errors) === true) {
                $data = array(
                                'first_name' => $_POST['first_name'],
                                'last_name' => $_POST['last_name'],
                                'username' => $_POST['username'],
                                'password' => $_POST['password'],
                                'email' => $_POST['email'],
                                'birthday' => date('d/m/Y', $_POST['birthday'])
                            );
                create_user($data);
                $message = "You have been registered succsessfuly! Please check your email for an activation email.";
            }
        }
   } else if (isset($_GET['action']) && $_GET['action'] == 'activate') {
        if (activate_user($_GET['username'], $_GET['key']) === true) {
            $message = "Your account was activated sucsesfully!";
        } else {
            $errors[] = "Could not activate account for an unknown reson.";
        }
   }
?>
<?php if (empty($message) === true) { ?>
    <?php if (empty($errors) === true) print_r($errors); ?>
    <form action="" method="post">
        <ul style="list-style: none;">
            <li>
                Username*:<br />
                <input type="text" name="username" />
            </li>
            <li>
                Passowrd*:<br />
                <input type="password" name="password" />
            </li>
            <li>
                Passowrd Again*:<br />
                <input type="password" name="password_again" />
            </li>
            <li>
                First Name*:<br />
                <input type="text" name="first_name" />
            </li>
            <li>
                Last Name:<br />
                <input type="text" name="last_name" />
            </li>
            <li>
                Email*:<br />
                <input type="text" name="email" />
            </li>
            <li>
                BirthDay* (11/06/1987):<br />
                <input type="text" name="birth_day" />
            </li>
            <li>
                <input type="submit" value="Register" />
            </li>
        </ul>
    </form>
<?php } else { ?>
    <?php echo $message; ?>
    <?php if ($message === "Your account was activated sucsesfully!") get_login_form(); ?>
<?php } ?>