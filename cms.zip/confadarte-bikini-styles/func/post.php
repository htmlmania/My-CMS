<?php
    include('functions.php');
    get_header();
    $id = $_GET['slug'];
    if (is_post($id) === true) {
        $id = get_post_id_from_slug($id);
        $info = get_post_info($id);
        $cat_info = get_category_info($info['cat_id']);
        $cat = $cat_info['name'];
?>
        <h1><?php echo $info['title']; ?></h1>
        <?php echo date('j/n/Y', strtotime($info['timestamp'])); ?> Category: <?php echo $cat; ?><br />
        <img src="<?php echo $info['image']; ?>" alt="<?php echo $info['title']; ?>" />
        <p><?php echo $info['content'] ?></p>
        <?php
            $_GET['post_id'] = $id;
            get_comments_dispaly();
            get_comment_form();
        ?>
<?php 
    } else {
        $_GET['error_code'] = '404';
        require ROOT . 'func/thats_an_error.php';
    }
    get_footer();
?>