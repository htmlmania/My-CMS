<?php
    if (isset($_POST['username'])) {
        login($_POST['username'], $_POST['password']);
?>
    <a href="javascript:history.back();"><< Back</a>
    <script type="text/javascript">
        function next() {
            
        }
        setInterval(next(), 1000);
    </script>
<?php
    } else {
        get_login_form();
    }
?>