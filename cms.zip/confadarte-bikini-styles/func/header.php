<?php ob_start(); ?>
<!DOCTYPE html>
<head>
    <title><?php echo $page_title; ?></title>
    <link rel="Stylesheet" type="text/css" href="<?php echo HTML_ROOT; ?>style.css" />
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
</head>
<?php
    $current = strtolower(str_replace(" ", "-", $page_title));
?>
<body id="<?php echo $current; ?>">
    <ul>
        <?php
            $dir = opendir(ROOT . 'pages/');
            while (false !== ($entry = readdir($dir))) {
                if ($entry != "." && $entry != "..") {
                    $name = ucwords(str_replace("_", " ", substr($entry, 0, -4)));
                    if($name == "Index") $name = "Home";
                    $class = strtolower(substr($entry, 0, -4));
                    $entry = HTML_ROOT  . str_replace("_", "-", substr($entry, 0, -4)). '/';
                    echo "<li class=\"$class\">\r\n<a href=\"$entry\">$name</a>\r\n</li>\r\n";
                    if ($name == "Home") echo "<li class=\"blog\">\r\n<a href=\"" . HTML_ROOT . "blog/\">Blog</a>\r\n</li>\r\n";
                }
            }
            if (loged_in() === true) {
                echo "<li class=\"logout\">\r\n<a href=\"" . HTML_ROOT . "logout/\">Logout</a>\r\n</li>\r\n";
            } else {
                echo "<li class=\"login\">\r\n<a href=\"" . HTML_ROOT . "login/\">Login</a>\r\n</li>\r\n";
                echo "<li class=\"register\">\r\n<a href=\"" . HTML_ROOT . "register/\">Register</a>\r\n</li>\r\n";
            }
            if (get_current_user_type() === 'admin') {
                echo "<li class=\"admin\">\r\n<a href=\"" . HTML_ROOT . "admin/index.php\">Dashboard</a>\r\n</li>\r\n";
            }
        ?>
    </ul>