<?php
    session_start();

    $page_title;
    $current;
    $root = "/stuff/confadarte-bikini-styles";
    $domain = "http://www.html-mania.co.uk";
    
    $conn = mysql_connect("db450462913.db.1and1.com", "dbo450462913", "Rwbwreia123") or die(mysql_error());
    mysql_select_db("db450462913", $conn);

    define(ROOT, dirname(dirname(__FILE__)) . '/');
    define(HTML_ROOT, $root . '/');
    define(DOMAIN, $website);
    
    if (isset($_SESSION['user'])) {
        if (user_active($_SESSION['user']) === false) {
            $username = $_SESSION['firstname'] . ' ' . $_SESSION['lastname'];
            session_destroy();
            echo "Your account has been disabeled $username.";
        }
    }
    
    function print_a($a) {
        print "<pre>";
        print_r($a);
        print "</pre>";
    }
    
    function user_exits($username) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `username` = '" . $username . "'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    function user_active($username) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `username` = '" . $username . "' AND active = '1'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    function email_exits($email) {
        $email = mysql_real_escape_string($email);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `email` = '" . $email . "'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    function user_count() {
        global $conn;
        $sql = "SELECT * FROM `users` WHERE active = '1'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        return mysql_num_rows($results);
    }
    
    function get_users() {
        global $conn;
        $sql = "SELECT * FROM users";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) >= 1) {
            $users = array();
            while ($user = mysql_fetch_array($results)) {
                $users[$user['personID']] = $user;
            }
            return $users;
        }
    }
    
    function check_pass($username, $password) {
        $username = mysql_real_escape_string($username);
        $password = md5($password);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `username` =  '$username' AND `password` =  '$password'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    function get_user_info($username) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $db_info = mysql_fetch_array($results);
            $info = array(
                        'personID' => $db_info['personID'],
                        'first_name' => $db_info['firstname'],
                        'last_name' => $db_info['lastname'],
                        'birthday' => $db_info['birthday'],
                        'email' => $db_info['email'],
                        'type' => $db_info['type']
                    );
            return $info;
        }
    }
    
    function update_user($username, $data) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "UPDATE users SET firtsname='" . $data['firts_name'] . "', lastname='" . $data['last_name'] . "', username='" . $data['username'] . "', password='" . $data['password'] . "', email='" . $data['email'] . "', birthday='" . $data['birthday'] . "' WHERE username = '$username'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function create_user($data) {
        global $conn;
        $activation_key = md5($data['birthday'] . date('r'));
        $sql = "INSERT INTO users (firstname, lastname, username, password, email, birthday, activation_key, type) VALUES ('" . $data['first_name'] . "', '" . $data['last_name'] . "', '" . $data['username'] . "', '" . md5($data['password']) . "', '" . $data['email'] . "', '" . $data['birthday'] . "', '" . $activation_key . "', 'standard')";
        mysql_query($sql, $conn) or die(mysql_error());
        $message = "Hello " . $data['first_name'] . ",\n\n";
        $message .= "To activate your accound with the username " . $data['username'] . " you must click on the link below:\n";
        $message .= WEBSITE . HTML_ROOT . "register.php?action=activate&username=" . $data['username'] . "&key=" . $activation_key . "\n\n";
        $message .= "Happy Times,\n Bochdewi";
        mail($data['email'], 'Account activation', $message, 'From: Bochdewi <bochdewi@hotmail.co.uk>');
    }
    
    function activate_user($username, $key) {
        $username = mysql_real_escape_string($username);
        $key = mysql_real_escape_string($key);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `username` = '" . $username . "' AND activation_key = '". $key . "'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $sql = "UPDATE users SET active='1' WHERE `username` = '" . $username . "'";
            mysql_query($sql, $conn) or die(mysql_error());
            return true;
        } else {
            return false;
        }
    }
    
    function change_user_type_to_admin($uername) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `username` = '" . $username . "' AND type = 'standard'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $sql = "UPDATE users SET type='admin' WHERE `username` = '" . $username . "'";
            mysql_query($sql, $conn) or die(mysql_error());
            return true;
        } else {
            return false;
        }
    }
    
    function change_user_type_to_standard($uername) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "SELECT * FROM `users` WHERE `username` = '" . $username . "' AND type = 'admin'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $sql = "UPDATE users SET type='standard' WHERE `username` = '" . $username . "'";
            mysql_query($sql, $conn) or die(mysql_error());
            return true;
        } else {
            return false;
        }
    }
    
    function delete_user($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "DELETE FROM users WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function get_user_id_from_name($username) {
        $username = mysql_real_escape_string($username);
        global $conn;
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info['id'];
        }
    }
    
    function get_user_name_from_id($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "SELECT * FROM users WHERE personID = '$id'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info['username'];
        }
    }
    
    function loged_in() {
        if (isset($_SESSION['user'], $_SESSION['pass'], $_SESSION['firstname'], $_SESSION['lastname'])) {
            return true;
        } else {
            return false;
        }
    }
    
    function get_current_username() {
        return $_SESSION['user'];
    }
    
    function get_current_user_type() {
        $user_info = get_user_info(get_current_username());
        $user_type = $user_info['type'];
        return $user_type;
    }
    
    function admin_area() {
        if (!loged_in() === true || !get_current_user_type() === 'admin') {
            $_GET['error_code'] = '401';
            require ROOT . 'func/thats_an_error.php';
            exit();
        }
    }
    
    function protect_page() {
        if (loged_in() === false) {
            $_GET['error_code'] = '401';
            require ROOT . 'func/thats_an_error.php';
            exit();
        }
    }
    
    function loged_in_redirect() {
        if (loged_in() === true) {
            $_GET['error_code'] = '403';
            require ROOT . 'func/thats_an_error.php';
            exit();
        }
    }
    
    function login($user, $pass) {
        if (user_exits($user) === true) {
            if (user_active($user) === true) {
                if (check_pass($user, $pass) === true) {
                    $user_info = get_user_info($user);
                    echo "Welcome, " . $user_info['first_name'] . ' ' . $user_info['last_name'] . "! Hope you enloy your visit!";
                    $_SESSION['user'] = $user;
                    $_SESSION['pass'] = $pass;
                    $_SESSION['firstname'] = $user_info['first_name'];
                    $_SESSION['lastname'] = $user_info['last_name'];
                } else {
                    echo 'Sorry, but wrong password!';
                }
            } else {
                echo 'Sorry, but your account is not activated!';
            }
        } else {
            echo 'Sorry, but wrong username!';
        }
    }

    function logout() {
        $username = $_SESSION['firstname'] . ' ' . $_SESSION['lastname'];
        session_destroy();
        echo "Bye bye! Hope we see you soon again " . $username . ".";
    }
    
    function get_gravatar( $email, $img = false, $s = 125, $d = 'monsterid', $r = 'g', $atts = array(), $echo = true ) {
        $url = 'http://www.gravatar.com/avatar/';
        $url .= md5( strtolower( trim( $email ) ) );
        $url .= "?s=$s&d=$d&r=$r";
        if ( $img ) {
            $url = '<img src="' . $url . '"';
            foreach ( $atts as $key => $val ) {
                $url .= ' ' . $key . '="' . $val . '"';
            }
            $url .= ' />';
        }
        if ($echo === true) echo $url; else return $url;
    }


    function get_header() {
        global $page_title;
        $title_array = explode('/', $_SERVER['REQUEST_URI']);
        $length = (count($title_array) - 2);
        $title = $title_array[$length];
        $title = ucwords(str_replace("_", " ", $title));
        if($title == "Index") $title = "Home";
        $page_title = $title;
        include(ROOT . "func/header.php");
    }
    
    function get_admin_header() {
        global $page_title;
        $title_array = explode('/', $_SERVER['REQUEST_URI']);
        $length = (count($title_array) - 2);
        $title = $title_array[$length];
        $title = ucwords(str_replace("_", " ", $title));
        if($title == "Index") $title = "Home";
        $page_title = $title;
        include(ROOT . "admin/header.php");
    }

    function get_footer() {
        include(ROOT . "func/footer.php");
    }
    
    function get_admin_footer() {
        include(ROOT . "admin/footer.php");
    }
    
    function get_login_form() {
        include(ROOT . "func/loginform.php");
    }
    
    function get_comment_form() {
        include(ROOT . "func/commentform.php");
    }
    
    function get_comments_dispaly() {
        include(ROOT . "func/comments.php");
    }
    function update_post($id, $data) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "UPDATE posts SET title='" . $data['title'] . "', content='" . $data['content'] . "', image='" . $data['image'] . "', slug='" . $data['slug'] . "', cat_id='" . $data['cat_id'] . "' WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function create_post($data) {
        global $conn;
        $sql = "INSERT INTO posts (title, content, image, slug, cat_id) VALUES ('" . $data['title'] . "', '" . $data['content'] . "', '" . $data['image'] . "', '" . $data['slug'] . "', '" . $data['cat_id'] . "')";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function get_post_info($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "SELECT * FROM posts WHERE id = '$id'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info;
        }
    }
    
    function get_posts($limit=5, $cat=NULL) {
        $limit = mysql_real_escape_string($limit);
        $cat = mysql_real_escape_string($cat);
        global $conn;
        if ($limit == NULL) {
            if ($cat == NULL) {
                $sql = "SELECT * FROM posts";
            } else {
                $sql = "SELECT * FROM posts WHERE cat_id = '$cat'";
            }
        } else {
            if ($cat == NULL) {
                $sql = "SELECT * FROM posts LIMIT $limit";
            } else {
                $sql = "SELECT * FROM posts WHERE cat_id = '$cat' LIMIT $limit";
            }
        }
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) >= 1) {
            $posts = array();
            while($post = mysql_fetch_array($results)) {
                $posts[$post['id']] = $post;
            }
            return $posts;
        }
    }
    
    function get_post_id_from_slug($slug) {
        $slug = mysql_real_escape_string($slug);
        global $conn;
        $sql = "SELECT * FROM posts WHERE slug = '$slug'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info['id'];
        }
    }
    
    function is_post($slug) {
        $slug = mysql_real_escape_string($slug);
        global $conn;
        $sql = "SELECT * FROM posts WHERE slug = '$slug'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    function delete_post($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "DELETE FROM posts WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function create_category($name, $slug) {
        $name = mysql_real_escape_string($name);
        $slug = mysql_real_escape_string($slug);
        global $conn;
        $sql = "INSERT INTO categories (name, slug) VALUES ('$name', '$slug')";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function update_category($id, $name, $slug) {
        $id = mysql_real_escape_string($id);
        $name = mysql_real_escape_string($name);
        $slug = mysql_real_escape_string($slug);
        global $conn;
        $sql = "UPDATE categories SET name='$name', slug='$slug' WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function get_category_info($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "SELECT * FROM categories WHERE id = '$id'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info;
        }
    }
    
    function get_categories() {
        global $conn;
        $sql = "SELECT * FROM categories";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) >= 1) {
            $categories = array();
            while($category = mysql_fetch_array($results)) {
                $categories[$category['id']] = $category;
            }
            return $categories;
        }
    }
    
    function get_category_id_from_slug($slug) {
        $slug = mysql_real_escape_string($slug);
        global $conn;
        $sql = "SELECT * FROM categories WHERE slug = '$slug'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info['id'];
        }
    }
    
    function is_category($slug) {
        $slug = mysql_real_escape_string($slug);
        global $conn;
        $sql = "SELECT * FROM categories WHERE slug = '$slug'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    function delete_category($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "DELETE FROM categories WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function post_comment($data) {
        $post_id = mysql_real_escape_string($data['post_id']);
        $user_id = mysql_real_escape_string($data['user_id']);
        $content = mysql_real_escape_string($data['content']);
        global $conn;
        $sql = "INSERT INTO comments (post_id, user_id, content) VALUES ('$post_id', '$user_id', '$content')";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function update_comment($id, $content) {
        $id = mysql_real_escape_string($id);
        $content = mysql_real_escape_string($content);
        global $conn;
        $sql = "UPDATE comments SET content='$content' WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function delete_comment($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "DELETE FROM comments WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function aprove_comment($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "UPDATE comments SET aproved='1' WHERE id = '$id'";
        mysql_query($sql, $conn) or die(mysql_error());
    }
    
    function get_comments($limit=15, $post_id=NULL, $user_id=NULL, $aproved=TRUE) {
        $limit = mysql_real_escape_string($limit);
        $post_id = mysql_real_escape_string($post_id);
        $user_id = mysql_real_escape_string($user_id);
        global $conn;
        if ($limit == NULL) {
            if ($post_id == NULL) {
                if ($user_id == NULL) {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments";
                    } else {
                        $sql = "SELECT * FROM comments WHERE aproved = '1'";
                    }
                } else {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments WHERE user_id = '$user_id'";
                    } else {
                        $sql = "SELECT * FROM comments WHERE user_id = '$user_id' AND aproved = '1'";
                    }
                }
            } else {
                if ($user_id == NULL) {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id'";
                    } else {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' AND aproved = '1'";
                    }
                } else {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' AND user_id = '$user_id'";
                    } else {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' AND user_id = '$user_id' AND aproved = '1'";
                    }
                }
            }
        } else {
            if ($post_id == NULL) {
                if ($user_id == NULL) {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments LIMIT $limit";
                    } else {
                        $sql = "SELECT * FROM comments WHERE aproved = '1' LIMIT $limit";
                    }
                } else {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments WHERE user_id = '$user_id' LIMIT $limit";
                    } else {
                        $sql = "SELECT * FROM comments WHERE user_id = '$user_id' AND aproved = '1' LIMIT $limit";
                    }
                }
            } else {
                if ($user_id == NULL) {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' LIMIT $limit";
                    } else {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' AND aproved = '1' LIMIT $limit";
                    }
                } else {
                    if ($aproved == FALSE) {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' AND user_id = '$user_id' LIMIT $limit";
                    } else {
                        $sql = "SELECT * FROM comments WHERE post_id = '$post_id' AND user_id = '$user_id' AND aproved = '1' LIMIT $limit";
                    }
                }
            }
        }
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) >= 1) {
            $comments = array();
            while($comment = mysql_fetch_array($results)) {
                $comments[$comment['id']] = $comment;
            }
            return $comments;
        }
    }
    
    function get_comment_info($id) {
        $id = mysql_real_escape_string($id);
        global $conn;
        $sql = "SELECT * FROM comments WHERE id = '$id'";
        $results = mysql_query($sql, $conn) or die(mysql_error());
        if (mysql_num_rows($results) == 1) {
            $info = mysql_fetch_array($results);
            return $info;
        }
    }