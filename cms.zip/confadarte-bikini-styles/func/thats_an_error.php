    <h1>Thats an error</h1>
    <?php
        $page_array = explode('/', $_SERVER['REQUEST_URI']);
        $length = (count($page_array) - 2);
        $error_page = $page_array[$length];
        $error_page = ucwords(str_replace("-", " ", str_replace("_", " ", $error_page)));
        $error_codes = array(
                                '400' => 'Your browser sent a bad request to view the page ' . $error_page,
                                '401' => 'You are unathorized to view the page ' . $error_page,
                                '404' => 'The page ' . $error_page . ' was not found',
                                '403' => 'You are forbiden to view the page ' . $error_page,
                                '500' => 'The sever encounterd an error wilst sending the page ' . $error_page
                            );
        $error_code = $_GET['error_code'];
        $error = $error_codes[$error_code];
    ?>
    <h3><?php echo $error_code; ?>: <?php echo $error; ?></h3>
    <a href="javascript:history.back();"><< Back</a>