<?php
    include('func/functions.php');
    $page_array = explode('/', $_SERVER['REQUEST_URI']);
    $length = (count($page_array) - 2);
    $page = $page_array[$length];
    $page = str_replace("-", "_", $page);
    $file = ROOT . 'pages/' . $page;
    if ($file == ROOT . 'pages/login') $file = ROOT . 'func/login';
    if ($file == ROOT . 'pages/logout') $file = ROOT . 'func/logout';
    if ($file == ROOT . 'pages/register') $file = ROOT . 'func/register';
    if ($file == ROOT . 'pages/blog') $file = ROOT . 'func/blog';
    get_header();
    if ($page == 'confadarte_bikini_styles') {
        require ROOT . 'pages/index.php';
    } else if (file_exists($file . '.php')) {
        require $file . '.php';
    } else {
        $_GET['error_code'] = '404';
        require ROOT . 'func/thats_an_error.php';
    }
    get_footer();
?>
                    