<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_POST['page'])) {
            $title = strtolower(str_replace(" ", "_", $_POST['page'])) . '.php';
            $file = fopen(ROOT . 'pages/' . $title, "w");
            if(!$file === false) {
                $content = $_POST['content'];
                echo fwrite($file,  stripslashes($content));
                fclose($file);
                header("Location: " . HTML_ROOT . "admin/edit_page?page=$title");
            }
       }
    ?>
        <form action="" method="post">
            <ul style="list-style: none;">
                <li>
                    Title:
                    <input type="text" name="page" />
                </li>
                <li>
                    Content:
                    <textarea name="content" style="width: 100%; height: 250px;"></textarea>
                </li>
                <li>
                    <input type="submit" value="Post" />
            </ul>
        </form>
<?php get_admin_footer(); ?>