<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_GET['action']) && $_GET['action'] == 'aprove') {
            aprove_comment($_GET['id']);
        }
        if (isset($_GET['action']) && $_GET['action'] == 'delete') {
            delete_comment($_GET['id']);
            header('Location: ' . HTML_ROOT . 'admin/edit_comment.php');
        }
        if (isset($_POST['content'])) {
            update_comment($_POST['id'], $_POST['content']);
            header('Location: ' . HTML_ROOT . 'admin/edit_comment.php');
        }
       if (isset($_GET['id'])) {
           $id = $_GET['id'];
           $comment_info = get_comment_info($id);
    ?>
        <form action="" method="post">
            <ul style="list-style: none;">
                <li>
                    Content:
                    <textarea name="content"><?php echo $comment_info['content']; ?></textarea>
                </li>
                <li>
                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" />
                    <input type="submit" value="Update" />
                </li>
            </ul>
        </form>
        <a href="<?php echo HTML_ROOT . 'admin/edit_comment.php?action=aprove&id=' . $_GET['id']; ?>">Aprove</a>
        <a href="<?php echo HTML_ROOT . 'admin/edit_comment.php?action=delete&id=' . $_GET['id']; ?>">Delete</a>
       <?php } else { ?>
       <?php
            $comments = get_comments(NULL, NULL, NULL, FALSE);
            if (is_array($comments)) {
        ?>
        <form action="" method="get">
            <ul style="list-style: none;">
                <li>
                    Comment:
                    <select name="id">
                        <?php
                                foreach ($comments as $comment) {
                                    $id = $comment['id'];
                                    $name = $comment['content'];
                                    echo "<option value=\"$id\">$name</option>";
                                }
                        ?>
                    </select>
                </li>
                    <input type="submit" value="Edit" />
                </li>
            </ul>
        </form>
        <?php } else { ?>
            <h3>There are no comments</h3>
        <?php } ?>
       <?php } ?>
<?php get_admin_footer(); ?>