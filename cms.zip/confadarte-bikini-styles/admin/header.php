<?php
    ob_start();
    admin_area();
?>
<!DOCTYPE html>
<head>
    <title><?php echo $page_title; ?></title>
    <link rel="Stylesheet" type="text/css" href="<?php echo HTML_ROOT; ?>style.css" />
</head>
<body>
    <ul>
        <?php
            echo "<li class=\"site\">\r\n<a href=\"" . HTML_ROOT. "\">Visit Site</a>\r\n</li>\r\n";
            $dir = opendir(ROOT . 'admin/');
            while (false !== ($entry = readdir($dir))) {
                if ($entry != "." && $entry != ".." && $entry != 'header.php' && $entry != 'footer.php') {
                    $name = ucwords(str_replace("_", " ", substr($entry, 0, -4)));
                    if($name == "Index") $name = "Dashboard";
                    $class = strtolower(substr($entry, 0, -4));
                    $entry = HTML_ROOT . "admin/" . $entry;
                    echo "<li class=\"$class\">\r\n<a href=\"$entry\">$name</a>\r\n</li>\r\n";
                }
            }
        ?>
    </ul>