<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_POST['delete'])) {
            $delete = $_POST['delete'];
            $id = $_POST['id'];
            if ($delete == 'user') {
                delete_user($id);
            }
            if ($delete == 'post') {
                delete_post($id);
            }
            if ($delete == 'category') {
                delete_category($id);
            }
            if ($delete == 'comment') {
                delete_comment($id);
            }
        }
        $users = get_users();
        if (is_array($users)) {
            if (count($users) != 1) {
    ?>
                <h3>Delete User</h3>
                <form action="" method="post">
                    <ul style="list-style: none;">
                        <li>
                            User:
                            <select name="id">
                                <?php
                                    foreach ($users as $user) {
                                        $id = $user['personID'];
                                        $name = $user['username'];
                                        echo "<option value=\"$id\">$name</option>";
                                    }
                                ?>
                            </select>
                        </li>
                        <li>
                            <input type="submit" value="Delete" />
                        </li>
                    </ul>
                </form>
    <?php
            }
        }
        $posts = get_posts(NULL);
        if (is_array($posts)) {
    ?>
            <h3>Delete Post</h3>
            <form action="" method="post">
                <ul style="list-style: none;">
                    <li>
                        Post:
                        <select name="id">
                            <?php
                                    foreach ($posts as $post) {
                                        $id = $post['id'];
                                        $name = $post['title'];
                                        echo "<option value=\"$id\">$name</option>";
                                    }
                            ?>
                        </select>
                    </li>
                    <li>
                        <input type="submit" value="Delete" />
                    </li>
                </ul>
            </form>
    <?php
        }
        $categories = get_categories();
        if (is_array($categories)) {
            if (count($categories) != 1) {
    ?>
                <h3>Delete Category</h3>
                <form action="" method="post">
                    <ul style="list-style: none;">
                        <li>
                            Category:
                            <select name="id">
                                <?php
                                    foreach ($categories as $category) {
                                        $id = $category['id'];
                                        $name = $category['name'];
                                        if ($name != 'Uncategorized') {
                                            echo "<option value=\"$id\">$name</option>";
                                        }
                                    }
                                ?>
                            </select>
                        </li>
                        <li>
                            <input type="submit" value="Delete" />
                        </li>
                    </ul>
                </form>
    <?php
            }
        }
        $comments = get_comments(NULL, NULL, NULL, FALSE);
        if (is_array($comments)) {
    ?>
            <h3>Delete Comment</h3>
            <form action="" method="post">
                <ul style="list-style: none;">
                    <li>
                        Comment:
                        <select name="id">
                            <?php
                                    foreach ($comments as $comment) {
                                        $id = $comment['id'];
                                        $name = $comment['content'];
                                        echo "<option value=\"$id\">$name</option>";
                                    }
                            ?>
                        </select>
                    </li>
                    <li>
                        <input type="submit" value="Delete" />
                    </li>
                </ul>
            </form>
    <?php
        }
    ?>
<?php get_admin_footer(); ?>