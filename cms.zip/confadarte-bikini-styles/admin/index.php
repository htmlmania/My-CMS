<?php
    include('../func/functions.php');
    get_admin_header();
?>
<?php get_admin_footer(); ?>