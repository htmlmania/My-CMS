<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_POST['page'])) {
            $file = fopen(ROOT . 'pages/' . $_POST['page'], "wb");
            if(!$file === false) {
                fwrite($file,  stripslashes($_POST['content']));
                fclose($file);
                $title = strtolower(str_replace(" ", "_", $_POST['title']));
                if ($title == 'home') $title = 'index';
                rename(ROOT . 'pages/' .  $_POST['page'], ROOT . 'pages/' . $title . '.php');
            }
       }
    ?>
    <?php if (isset($_GET['page'])) { ?>
        <?php
            $file = fopen(ROOT . 'pages/' . $_GET['page'], "r+");
                if($file) {
                $contents = '';
                    while(!feof($file)) {
                        $contents .= fgets($file) . "\n";
                    }
                }
                fclose($file);
                $title_array = explode('/', $_GET['page']);
                $length = (count($title_array) - 1);
                $title = $title_array[$length];
                $title = ucwords(str_replace("_", " ", substr($title, 0, -4)));
                if ($title == 'Index') $title = 'Home';
        ?>
        <a href="<?php echo HTML_ROOT . substr($_GET['page'], 0, -4) . '/'; ?>"><?php echo $title; ?></a>
        <form action="" method="post">
            <ul style="list-style: none;">
                <li>
                    Title:
                    <input type="text" name="title" value="<?php echo $title; ?>" />
                </li>
                <li>
                    Content:
                    <textarea name="content" style="width: 100%; height: 250px;"><?php echo $contents; ?></textarea>
                </li>
                <li>
                    <input type="hidden" name="page" value="<?php echo $_GET['page']; ?>" />
                    <input type="submit" value="Update" />
            </ul>
        </form>
    <?php } else { ?>
        <form action="" method="get">
            <ul style="list-style: none;">
                <li>
                    <select name="page">
                        <?php
                            $dir = opendir(ROOT . 'pages/');
                            while (false !== ($entry = readdir($dir))) {
                                if ($entry != "." && $entry != ".." && $entry != 'header.php' && $entry != 'footer.php') {
                                    $name = ucwords(str_replace("_", " ", substr($entry, 0, -4)));
                                    if($name == "Index") $name = "Home";
                                    echo "<option value=\"$entry\">$name</option>\r\n";
                                }
                            }
                        ?>
                    </select>
                </li>
                <li>
                    <input type="submit" value="Edit" />
                </li>
            </ul>
        </form>
    <?php } ?>
<?php get_admin_footer(); ?>