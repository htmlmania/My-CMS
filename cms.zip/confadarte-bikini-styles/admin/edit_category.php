<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_POST['title'])) {
            update_category($_POST['id'], $_POST['title'], $_POST['slug']);
       }
       if (isset($_GET['id'])) {
           $id = $_GET['id'];
           $category_info = get_category_info($id);
    ?>
        <form action="" method="post">
            <ul style="list-style: none;">
                <li>
                    Title:
                    <input type="text" name="title" value="<?php echo $category_info['name']; ?>" />
                </li>
                <li>
                    Slug:
                    <input type="text" name="slug" value="<?php echo $category_info['slug']; ?>" />
                </li>
                <li>
                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" />
                    <input type="submit" value="Update" />
                </li>
            </ul>
        </form>
       <?php } else { ?>
        <form action="" method="get">
            <ul style="list-style: none;">
                <li>
                    Category:
                    <select name="id">
                        <?php
                            $categories = get_categories();
                            if (is_array($categories)) {
                                foreach ($categories as $category) {
                                    $id = $category['id'];
                                    $name = $category['name'];
                                    echo "<option value=\"$id\">$name</option>";
                                }
                            }
                        ?>
                    </select>
                </li>
                    <input type="submit" value="Edit" />
                </li>
            </ul>
        </form>
       <?php } ?>
<?php get_admin_footer(); ?>