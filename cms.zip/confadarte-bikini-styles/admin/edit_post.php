<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_POST['title'])) {
            if(!$_FILES["image"]["error"] == 4) {
                if ($_FILES["image"]["error"] > 0) {
                    echo "Error: " . $_FILES['image']["error"];
                } else {
                    if (file_exists(ROOT . "uploads/" . $_FILES["image"]["name"])) {
                        unlink(ROOT . "uploads/" . $_FILES["image"]["name"]);
                    }
                        move_uploaded_file($_FILES["image"]["tmp_name"], ROOT . "uploads/" . $_FILES["image"]["name"]);
                        $data = array(
                                        'title' => $_POST['title'],
                                        'content' => $_POST['content'],
                                        'image' => HTML_ROOT . "uploads/" . $_FILES["image"]["name"],
                                        'slug' => $_POST['slug'],
                                        'cat_id' => $_POST['cat_id']
                                    );
                        update_post($_POST['id'], $data);
                }
            } else {
                $orig_img = get_post_info($_POST['id']);
                $orig_img = $orig_img['image'];
                $data = array(
                                'title' => $_POST['title'],
                                'content' => $_POST['content'],
                                'image' => $orig_img,
                                'slug' => $_POST['slug'],
                                'cat_id' => $_POST['cat_id']
                            );
                update_post($_POST['id'], $data);
            }
       }
       if (isset($_GET['id'])) {
           $id = $_GET['id'];
           $post_info = get_post_info($id);
    ?>
        <form action="" method="post" enctype="multipart/form-data">
            <ul style="list-style: none;">
                <li>
                    Title:
                    <input type="text" name="title" value="<?php echo $post_info['title']; ?>" />
                </li>
                <li>
                    Slug:
                    <input type="text" name="slug" value="<?php echo $post_info['slug']; ?>" />
                </li>
                <li>
                    Category:
                    <select name="cat_id">
                        <?php
                            $categories = get_categories();
                            if (is_array($categories)) {
                                foreach ($categories as $category) {
                                    $id = $category['id'];
                                    $name = $category['name'];
                                    if ($id == $post_info['cat_id']) {
                                        echo "<option value=\"$id\" selected=\"selected\">$name</option>";
                                    } else {
                                        echo "<option value=\"$id\">$name</option>";
                                    }
                                }
                            }
                        ?>
                    </select>
                </li>
                <li>
                    Content:
                    <textarea name="content" style="width: 100%; height: 250px;"><?php echo $post_info['content']; ?></textarea>
                </li>
                <li>
                    Image:
                    <input type="file" name="image" value="<?php echo $post_info['image']; ?>" />
                </li>
                <li>
                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" />
                    <input type="submit" value="Update" />
                </li>
            </ul>
        </form>
       <?php } else { ?>
        <form action="" method="get">
            <ul style="list-style: none;">
                <li>
                    <select name="id">
                        <?php
                            $posts = get_posts(NULL);
                            if (is_array($posts)) {
                                foreach ($posts as $post) {
                                    $id = $post['id'];
                                    $name = $post['title'];
                                    echo "<option value=\"$id\">$name</option>";
                                }
                            }
                        ?>
                    </select>
                </li>
                    <input type="submit" value="Edit" />
                </li>
            </ul>
        </form>
       <?php } ?>
<?php get_admin_footer(); ?>