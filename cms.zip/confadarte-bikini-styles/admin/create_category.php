<?php include("../func/functions.php"); ?>
<?php get_admin_header(); ?>
    <?php
        if (isset($_POST['title'])) {
            create_category($_POST['title'], $_POST['slug']);
            $id = get_category_id_from_slug($_POST['slug']);
            header("Location: " . HTML_ROOT . "admin/edit_category?id=$id");
       }
    ?>
        <form action="" method="post">
            <ul style="list-style: none;">
                <li>
                    Title:
                    <input type="text" name="title" />
                </li>
                <li>
                    Slug:
                    <input type="text" name="slug" />
                </li>
                <li>
                    <input type="submit" value="Create" />
                </li>
            </ul>
        </form>
<?php get_admin_footer(); ?>